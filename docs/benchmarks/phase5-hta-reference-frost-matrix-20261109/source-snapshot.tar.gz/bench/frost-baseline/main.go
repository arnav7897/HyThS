package main

import (
	"flag"
	"fmt"
	"os"
	"runtime"
	"time"

	"github.com/bytemare/frost"
	"github.com/bytemare/frost/debug"
	"github.com/bytemare/secret-sharing/keys"
)

const frostCommit = "316cadd937fd546ac3b01bd36e837090b9b1f8f0"

func must(err error) {
	if err != nil {
		panic(err)
	}
}

func ns(start time.Time) int64 {
	return time.Since(start).Nanoseconds()
}

func main() {
	n := flag.Uint("n", 8, "registered participants")
	t := flag.Uint("t", 4, "FROST threshold")
	k := flag.Uint("k", 5, "selected signers")
	samples := flag.Uint("samples", 25, "measured sessions")
	flag.Parse()
	if *n == 0 || *n > 65535 || *t == 0 || *t > *k || *k > *n || *samples == 0 {
		fmt.Fprintln(os.Stderr, "require 1 <= t <= k <= n <= 65535 and samples > 0")
		os.Exit(2)
	}

	start := time.Now()
	shares, verificationKey, _ := debug.TrustedDealerKeygen(
		frost.Secp256k1, nil, uint16(*t), uint16(*n))
	publicShares := make([]*keys.PublicKeyShare, 0, len(shares))
	for _, share := range shares {
		publicShares = append(publicShares, share.PublicKeyShare())
	}
	configuration := &frost.Configuration{
		Ciphersuite:           frost.Secp256k1,
		Threshold:             uint16(*t),
		MaxSigners:            uint16(*n),
		VerificationKey:       verificationKey,
		SignerPublicKeyShares: publicShares,
	}
	must(configuration.Init())
	signers := make([]*frost.Signer, *k)
	for i := range signers {
		var err error
		signers[i], err = configuration.Signer(shares[i])
		must(err)
	}
	setupNS := ns(start)
	fmt.Printf("{\"type\":\"metadata\",\"protocol\":\"FROST-RFC9591\",\"implementation\":\"bytemare/frost\",\"commit\":\"%s\",\"go\":\"%s\",\"os\":\"%s\",\"arch\":\"%s\",\"setup\":\"trusted-dealer\",\"n\":%d,\"t\":%d,\"k\":%d,\"setup_ns\":%d}\n",
		frostCommit, runtime.Version(), runtime.GOOS, runtime.GOARCH, *n, *t, *k, setupNS)

	for sample := uint(0); sample <= *samples; sample++ {
		message := []byte(fmt.Sprintf("hta-frost-baseline-%d", sample))
		commitments := make(frost.CommitmentList, len(signers))
		start = time.Now()
		for i, signer := range signers {
			commitments[i] = signer.Commit()
		}
		commitNS := ns(start)

		start = time.Now()
		commitments.Sort()
		commitAggregationNS := ns(start)

		signatureShares := make([]*frost.SignatureShare, len(signers))
		start = time.Now()
		for i, signer := range signers {
			var err error
			signatureShares[i], err = signer.Sign(message, commitments)
			must(err)
		}
		signNS := ns(start)

		start = time.Now()
		for _, share := range signatureShares {
			must(configuration.VerifySignatureShare(share, message, commitments))
		}
		verifySharesNS := ns(start)

		start = time.Now()
		signature, err := configuration.AggregateSignatures(message, signatureShares, commitments, false)
		must(err)
		aggregateNS := ns(start)

		start = time.Now()
		must(frost.VerifySignature(frost.Secp256k1, message, signature, verificationKey))
		verifyNS := ns(start)

		if sample == 0 {
			continue
		}
		fmt.Printf("{\"type\":\"sample\",\"protocol\":\"FROST-RFC9591\",\"n\":%d,\"t\":%d,\"k\":%d,\"sample\":%d,\"commit_round1_ns\":%d,\"commitment_aggregation_ns\":%d,\"sign_round2_ns\":%d,\"share_verification_ns\":%d,\"response_aggregation_ns\":%d,\"final_verification_ns\":%d,\"signature_bytes\":%d}\n",
			*n, *t, *k, sample-1, commitNS, commitAggregationNS, signNS,
			verifySharesNS, aggregateNS, verifyNS, len(signature.Encode()))
	}
}
