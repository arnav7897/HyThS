module hta-frost-baseline

go 1.26.3

require (
	github.com/bytemare/frost v0.0.0-20260616005703-316cadd937fd
	github.com/bytemare/secret-sharing v0.8.1-0.20260608010144-f8126702fd4d
)

require (
	filippo.io/edwards25519 v1.2.0 // indirect
	filippo.io/nistec v0.0.4 // indirect
	github.com/bytemare/ecc v0.10.0 // indirect
	github.com/bytemare/hash v0.6.3 // indirect
	github.com/bytemare/secp256k1 v0.5.0 // indirect
	github.com/gtank/ristretto255 v0.2.0 // indirect
	golang.org/x/crypto v0.53.0 // indirect
	golang.org/x/sys v0.46.0 // indirect
)
