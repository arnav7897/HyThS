#!/usr/bin/env python3
"""Run pinned secp256k1 FROST sessions and retain raw JSONL timing samples."""

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DRIVER = ROOT / "bench" / "frost-baseline"


def parse_config(value):
    try:
        n, threshold, signers = (int(part) for part in value.split(","))
    except (ValueError, TypeError) as error:
        raise argparse.ArgumentTypeError("expected n,t,k") from error
    if not (1 <= threshold <= signers <= n <= 65535):
        raise argparse.ArgumentTypeError("require 1 <= t <= k <= n <= 65535")
    return n, threshold, signers


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", action="append", type=parse_config, default=[])
    parser.add_argument("--launches", type=int, default=5)
    parser.add_argument("--samples", type=int, default=25)
    parser.add_argument(
        "--out", type=Path, default=ROOT / "docs/benchmarks/phase5-frost-20261109.jsonl"
    )
    args = parser.parse_args()
    if args.launches < 1 or args.samples < 1:
        parser.error("launches and samples must be positive")
    configs = args.config or [(8, 4, 5)]
    args.out.parent.mkdir(parents=True, exist_ok=True)

    with args.out.open("w", encoding="utf-8") as output:
        for n, threshold, signers in configs:
            for launch in range(args.launches):
                command = [
                    "go",
                    "run",
                    ".",
                    "-n",
                    str(n),
                    "-t",
                    str(threshold),
                    "-k",
                    str(signers),
                    "-samples",
                    str(args.samples),
                ]
                result = subprocess.run(
                    command,
                    cwd=DRIVER,
                    check=True,
                    capture_output=True,
                    text=True,
                )
                for line in result.stdout.splitlines():
                    record = json.loads(line)
                    record["launch"] = launch
                    output.write(json.dumps(record, sort_keys=True) + "\n")
            print(f"n={n},t={threshold},k={signers}: {args.launches} launches")
    print(args.out)


if __name__ == "__main__":
    main()
